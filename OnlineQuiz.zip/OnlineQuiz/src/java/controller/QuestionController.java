/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Question;
import java.util.*;
import javax.servlet.RequestDispatcher;

/**
 *
 * @author sys.4
 */
public class QuestionController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet QuestionController</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet QuestionController at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session=request.getSession();
        List<Question> questions=(List<Question>)session.getAttribute("qlist");
        int qno=(Integer)session.getAttribute("qno");
        String b=request.getParameter("btn");
       Map<Integer,Integer> ans=(Map<Integer,Integer>)session.getAttribute("userans");
        if(b.equals("Start Quiz"))
        {
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
             Date date = new Date();  
            session.setAttribute("starttime",formatter.format(date));  
            Question q=questions.get(qno-1);
            request.setAttribute("question", q);
        }
        else if(b.equals("Next"))
        {
           int answer=0;
            if(request.getParameter("q1")!=null)
            {
              answer=Integer.parseInt(request.getParameter("q1"));
              ans.put(qno, answer);
            }
             int i=qno+1;
            Question q=questions.get(i-1);
            session.setAttribute("qno",i);
            request.setAttribute("question", q);
             
        } else if(b.equals("Previous"))
        {
            int answer=0;
            if(request.getParameter("q1")!=null)
            {
              answer=Integer.parseInt(request.getParameter("q1"));
              ans.put(qno, answer);
            }
             int i=qno-1;
            Question q=questions.get(i-1);
            session.setAttribute("qno",i);
            request.setAttribute("question", q); 
        } else if(b.equals("Finish Test"))
        {
            int answer=0;
            if(request.getParameter("q1")!=null)
            {
              answer=Integer.parseInt(request.getParameter("q1"));
              ans.put(qno, answer);
            }
           RequestDispatcher rd=request.getRequestDispatcher("result.jsp");
        rd.forward(request, response);
          return;
        }
        
        RequestDispatcher rd=request.getRequestDispatcher("ques.jsp");
        rd.forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
