/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.util.*;

/**
 *
 * @author sys.4
 */
public class QuestionEvaluation {
    public int evaluateQuestions(List<Question> ques,Map<Integer,Integer> ans)
    {
        int correctans=0;
       for(int i=0;i<ans.size();i++)
       {
           Question q=ques.get(i);
           if(q.getAns()==ans.get(i+1))
               correctans=correctans+1;
       }
        return correctans;
    }
}
