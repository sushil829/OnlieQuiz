/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

/**
 *
 * @author sys.4
 */
public class QuestionDAO {
   public List<Question> getQuestionList()
   {
         List<Question> lst=new ArrayList<Question>();
       try
       {
           Context ctx=new InitialContext();
           DataSource ds=(DataSource)ctx.lookup("java:comp/env/jdbc/stDB");
           Connection con=ds.getConnection();
           Statement st=con.createStatement();
           ResultSet res=st.executeQuery("select * from question");
           while(res.next())
           {
               lst.add(new Question(res.getInt(1),res.getString(2),res.getString(3),res.getString(4),res.getString(5),res.getString(6),res.getInt(7)));
           }
           res.close();
           con.close();
           
       }
       catch(Exception e)
       {
           
       }
    return   lst;
   }
}
